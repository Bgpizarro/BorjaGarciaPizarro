package indra.talentCamp.springBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaseDieciseisApplicationTests {

	@Test
	void contextLoads() {
	}

}
