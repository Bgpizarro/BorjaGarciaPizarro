package indra.talentCamp.springBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaseDieciseisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaseDieciseisApplication.class, args);
	}

}
